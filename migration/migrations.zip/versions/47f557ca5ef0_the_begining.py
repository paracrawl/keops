"""The begining

Revision ID: 47f557ca5ef0
Revises: 
Create Date: 2019-09-13 11:56:06.741121

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '47f557ca5ef0'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass